Overleaf package for cas_calmnet
=================================

Upload this zip to Overleaf via New Project -> Upload Project.

Main file:  cas_calmnet.tex   (root level, auto-detected)
Compiler:   pdfLaTeX
Bibliography: BibTeX (not biber)

Figure paths are flattened to the archive root, so they differ from the
repository, where the same figures live in ../results/. Nothing else differs.

Contents
  cas_calmnet.tex              manuscript
  tables_auto.tex              generated tables, \input by the manuscript
  refs.bib                     bibliography
  cas-dc.cls, cas-common.sty   Elsevier CAS double-column class
  elsarticle-num-names.bst     numbered style that still supplies author names
  fig_*.pdf                    figures
  cas_calmnet_reference.pdf    locally compiled output, for comparison

If Overleaf reports a missing \citet author, confirm the bibliography style is
elsarticle-num-names and not elsarticle-num; the latter supplies no names.
